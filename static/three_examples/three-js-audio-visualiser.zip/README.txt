A Pen created at CodePen.io. You can find this one at https://codepen.io/zadvorsky/pen/vNVNYr.

 more webgl particles!
this time with music.